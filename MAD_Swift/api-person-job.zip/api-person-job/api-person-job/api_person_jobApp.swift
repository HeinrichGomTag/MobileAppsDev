//
//  api_person_jobApp.swift
//  api-person-job
//
//  Created by Enrique Gomez Tagle on 28/03/23.
//

import SwiftUI

@main
struct api_person_jobApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
