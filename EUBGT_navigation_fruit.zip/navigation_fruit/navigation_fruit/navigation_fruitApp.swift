//
//  navigation_fruitApp.swift
//  navigation_fruit
//
//  Created by Enrique Gomez Tagle on 23/03/23.
//

import SwiftUI

@main
struct navigation_fruitApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
