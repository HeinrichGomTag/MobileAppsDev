//
//  EUBGT_EXAM1App.swift
//  EUBGT_EXAM1
//
//  Created by Enrique Gomez Tagle on 23/02/23.
//

import SwiftUI

@main
struct EUBGT_EXAM1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
